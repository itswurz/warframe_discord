# cogs/mods.py
# ─────────────────────────────────────────────────────────────────────────────
# !mods          — Browse your mod collection (stacked by name, paginated)
# !mods upgrade <mod_uuid>  — Upgrade a specific mod instance with Endo + Credits
# !mods view    <mod_uuid>  — Inspect any mod by UUID (cross-player)
#
# Fixes applied:
#   1. Removed content= kwarg from ctx.send(view=LayoutView) — Components v2
#      messages must not mix a top-level content string with a LayoutView.
#      The header text now lives inside the first Container.
#   2. Made UUID lookup case-insensitive as a safety net (stored UUIDs are
#      always uppercase, but defensive matching prevents silent mismatches).
#   3. Fixed UpgradeConfirmView custom_ids to be per-user so concurrent
#      upgrade confirmations from different players don't collide.
# ─────────────────────────────────────────────────────────────────────────────

from __future__ import annotations

import json
import math
import os
from typing import Optional

import discord
from discord.ext import commands

from data import persistence
from data.persistence import (
    load_player,
    save_player,
    find_mod_by_uuid,
    endo_cost_next_rank,
    credit_cost_next_rank,
)

# ── Codex data ────────────────────────────────────────────────────────────────
_DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "warframes_mods.json")
_DB: dict | None = None


def _db() -> dict:
    global _DB
    if _DB is None:
        with open(_DB_PATH, "r", encoding="utf-8") as f:
            _DB = json.load(f)
    return _DB


def _get_codex_mod(name: str) -> Optional[dict]:
    name_l = name.lower()
    for m in _db()["mods"]:
        if m["name"].lower() == name_l:
            return m
    return None


# ── Case-insensitive UUID helpers ──────────────────────────────────────────────

def _get_mod_by_uuid(profile: dict, mod_uuid: str) -> Optional[dict]:
    """Case-insensitive UUID lookup — guards against any historic casing quirks."""
    uuid_upper = mod_uuid.upper()
    for mod in profile.get("mod_collection", []):
        if mod.get("uuid", "").upper() == uuid_upper:
            return mod
    return None


# ── Display helpers ────────────────────────────────────────────────────────────

_RARITY_EMOJI = {
    "rare":     "<:rare:1499767261236297899>",
    "uncommon": "<:uncommon:1499767231926636705>",
    "common":   "<:common:1499767200410636351>",
}
_RARITY_TAG = {"rare": "R", "uncommon": "U", "common": "C"}

PAGE_SIZE = 6  # mod groups per page


def _rank_bar(rank: int, max_rank: int, length: int = 10) -> str:
    if max_rank == 0:
        return "`——————` Unrankable"
    ratio  = rank / max_rank
    filled = round(ratio * length)
    return f"`{'█' * filled}{'░' * (length - filled)}` {rank}/{max_rank}"


def _stat_at_rank(codex_mod: dict, rank: int) -> dict:
    """
    Compute scaled stat values at a given rank.
    Formula: stat = per_rank * rank   (rank 0 = 0 for percent stats)
    """
    if rank == 0:
        return {}
    scaling = codex_mod.get("rank_scaling", {})
    result  = {}
    for stat_key, scale_info in scaling.items():
        per_rank = scale_info.get("per_rank", 0)
        result[stat_key] = round(per_rank * rank, 2)
    if not result and rank >= codex_mod.get("max_rank", 5):
        result = dict(codex_mod.get("stats", {}))
    return result


def _fmt_stat(key: str, value: float) -> str:
    """Format a stat key/value into a human-readable string."""
    labels = {
        "health_percent":             f"+{value:.0f}% Health",
        "shields_percent":            f"+{value:.0f}% Shields",
        "armor_percent":              f"+{value:.0f}% Armor",
        "energy_percent":             f"+{value:.0f}% Energy",
        "ability_efficiency_percent": f"-{value:.0f}% Ability Cost",
        "puncture_resist_percent":    f"+{value:.0f}% Puncture Resist",
        "knockdown_chance_percent":   f"+{value:.0f}% KD Chance",
        "loot_bonus_percent":         f"+{value:.0f}% Loot Bonus",
        "electricity_store_percent":  f"+{value:.0f}% Arc Store",
    }
    return labels.get(key, f"+{value:.0f}% {key.replace('_', ' ').title()}")


def _endo_cost_at_rank(codex_mod: dict | None, from_rank: int, rarity: str) -> int:
    """
    Get Endo cost to go from `from_rank` to `from_rank+1`.
    Prefers the codex array; falls back to persistence formula.
    """
    if codex_mod:
        costs = codex_mod.get("endo_costs_per_rank", [])
        if 0 <= from_rank < len(costs):
            return costs[from_rank]
    max_rank = codex_mod.get("max_rank", 5) if codex_mod else 5
    return endo_cost_next_rank(from_rank, max_rank, rarity)


def _credit_cost_at_rank(codex_mod: dict | None, from_rank: int, rarity: str) -> int:
    """
    Get Credit cost to go from `from_rank` to `from_rank+1`.
    Prefers the codex array; falls back to persistence formula.
    """
    if codex_mod:
        costs = codex_mod.get("credit_costs_per_rank", [])
        if 0 <= from_rank < len(costs):
            return costs[from_rank]
    max_rank = codex_mod.get("max_rank", 5) if codex_mod else 5
    return credit_cost_next_rank(from_rank, max_rank, rarity)


# ── ContainerBuilder (Components v2) ──────────────────────────────────────────

class _CB:
    def __init__(self, **kw):
        self.items = []
        self.kw = kw

    def text(self, content: str):
        self.items.append(discord.ui.TextDisplay(content))
        return self

    def sep(self, visible: bool = True,
            spacing: discord.SeparatorSpacing = discord.SeparatorSpacing.small):
        self.items.append(discord.ui.Separator(visible=visible, spacing=spacing))
        return self

    def row(self, *components):
        self.items.append(discord.ui.ActionRow(*components))
        return self

    def build(self) -> discord.ui.Container:
        return discord.ui.Container(*self.items, **self.kw)


# ─────────────────────────────────────────────────────────────────────────────
# Mod collection stacking
# ─────────────────────────────────────────────────────────────────────────────

def _group_mods(mod_collection: list[dict]) -> list[dict]:
    """
    Group mod_collection by name.
    Returns list of group dicts sorted rare→uncommon→common then A-Z:
    {
      name, rarity, codex_mod, count,
      copies: [{uuid, rank, max_rank, equipped_on_warframe, acquired_at}]
    }
    """
    order = {"rare": 0, "uncommon": 1, "common": 2}
    groups: dict[str, dict] = {}

    for inst in mod_collection:
        name = inst["name"]
        if name not in groups:
            cm = _get_codex_mod(name)
            groups[name] = {
                "name":      name,
                "rarity":    inst.get("rarity", "common"),
                "codex_mod": cm,
                "count":     0,
                "copies":    [],
            }
        groups[name]["count"] += 1
        groups[name]["copies"].append({
            "uuid":                 inst["uuid"],
            "rank":                 inst.get("rank", 0),
            "max_rank":             inst.get("max_rank", 5),
            "equipped_on_warframe": inst.get("equipped_on_warframe"),
            "acquired_at":          inst.get("acquired_at", ""),
        })

    result = sorted(
        groups.values(),
        key=lambda g: (order.get(g["rarity"], 9), g["name"]),
    )
    return result


# ─────────────────────────────────────────────────────────────────────────────
# !mods  (list view)
# ─────────────────────────────────────────────────────────────────────────────

def _build_mods_list_layout(
    user_id:      int,
    mod_groups:   list[dict],
    page:         int,
    endo_amount:  int,
    credits:      int,
    owner_name:   str = "",
) -> discord.ui.LayoutView:
    total_pages = max(1, math.ceil(len(mod_groups) / PAGE_SIZE))
    page = max(0, min(page, total_pages - 1))
    slice_ = mod_groups[page * PAGE_SIZE: (page + 1) * PAGE_SIZE]

    total_mods   = sum(g["count"] for g in mod_groups)
    total_unique = len(mod_groups)

    # ── Header — Components v2 text lives INSIDE the container, not as content=
    owner_tag = f"**{owner_name}'s** " if owner_name else ""
    header = (
        _CB(accent_colour=0x1F4E5F)
        .text(
            f"<:wf_lotus:1499651243101126816>  {owner_tag}**Mod Collection**  ·  "
            f"Page {page + 1}/{total_pages}\n"
            f"**{total_mods}** total  ·  **{total_unique}** unique  ·  "
            f"<:endo:1499750353002954792> **{endo_amount:,}** Endo  ·  "
            f"💰 **{credits:,}** Credits"
        )
        .sep(visible=False)
    )

    # ── Mod entries ───────────────────────────────────────────────────────────
    lines: list[str] = []
    for g in slice_:
        cm    = g["codex_mod"]
        re    = _RARITY_EMOJI.get(g["rarity"], "📦")
        rtag  = _RARITY_TAG.get(g["rarity"], "?")
        icon  = cm["icon"] if cm else re
        count = g["count"]

        # Show each copy's UUID + rank inline
        copy_parts = []
        for c in g["copies"]:
            eq_tag = " 🔧" if c["equipped_on_warframe"] else ""
            rk_tag = f" R{c['rank']}/{c['max_rank']}" if c["max_rank"] > 0 else ""
            copy_parts.append(f"`{c['uuid']}`{rk_tag}{eq_tag}")

        copies_str = "  ".join(copy_parts)

        # Stats at max rank for reference
        stat_str = ""
        if cm:
            cur_stats = _stat_at_rank(cm, cm.get("max_rank", 5))
            parts = [_fmt_stat(k, v) for k, v in cur_stats.items()]
            stat_str = f" — *{', '.join(parts[:2])} (max)*" if parts else ""

        lines.append(
            f"{icon} **{g['name']}** `[{rtag}]` ×{count}{stat_str}\n"
            f"  {copies_str}"
        )

    content = "\n\n".join(lines) if lines else "*No mods in collection yet.*"
    header.text(content)
    header.sep()

    # ── Tip ───────────────────────────────────────────────────────────────────
    header.text(
        "Use `!mods upgrade <UUID>` to rank up a mod with Endo + Credits.\n"
        "Use `!mods view <UUID>` to inspect any mod in detail.\n"
        "🔧 = equipped on a Warframe"
    )

    # ── Pagination buttons ────────────────────────────────────────────────────
    prev_btn = discord.ui.Button(
        style=discord.ButtonStyle.secondary, label="◀ Prev",
        custom_id=f"mods_list_prev_{user_id}", disabled=(page <= 0),
    )
    page_btn = discord.ui.Button(
        style=discord.ButtonStyle.secondary, label=f"{page + 1} / {total_pages}",
        custom_id=f"mods_list_page_{user_id}", disabled=True,
    )
    next_btn = discord.ui.Button(
        style=discord.ButtonStyle.secondary, label="Next ▶",
        custom_id=f"mods_list_next_{user_id}", disabled=(page >= total_pages - 1),
    )

    async def _prev(interaction: discord.Interaction) -> None:
        if interaction.user.id != user_id:
            await interaction.response.send_message("Not your panel.", ephemeral=True)
            return
        _profile = await load_player(user_id)
        _groups  = _group_mods(_profile.get("mod_collection", []))
        _endo    = _profile.get("inventory", {}).get("Endo", 0)
        _creds   = _profile.get("credits", 0)
        layout   = _build_mods_list_layout(user_id, _groups, page - 1, _endo, _creds)
        await interaction.response.edit_message(view=layout)

    async def _next(interaction: discord.Interaction) -> None:
        if interaction.user.id != user_id:
            await interaction.response.send_message("Not your panel.", ephemeral=True)
            return
        _profile = await load_player(user_id)
        _groups  = _group_mods(_profile.get("mod_collection", []))
        _endo    = _profile.get("inventory", {}).get("Endo", 0)
        _creds   = _profile.get("credits", 0)
        layout   = _build_mods_list_layout(user_id, _groups, page + 1, _endo, _creds)
        await interaction.response.edit_message(view=layout)

    prev_btn.callback = _prev
    next_btn.callback = _next

    header.row(prev_btn, page_btn, next_btn)

    layout = discord.ui.LayoutView()
    layout.add_item(header.build())
    return layout


# ─────────────────────────────────────────────────────────────────────────────
# !mods view  (detail card — cross-player)
# ─────────────────────────────────────────────────────────────────────────────

def _build_mod_view_layout(
    mod_inst:     dict,
    codex_mod:    Optional[dict],
    owner_name:   str,
    owner_id:     str,
    warframe_ctx: str,
    is_owner:     bool,
) -> discord.ui.LayoutView:
    name   = mod_inst["name"]
    rarity = mod_inst.get("rarity", "common")
    rank   = mod_inst.get("rank", 0)
    max_r  = mod_inst.get("max_rank", codex_mod.get("max_rank", 5) if codex_mod else 5)
    uuid   = mod_inst["uuid"]
    re     = _RARITY_EMOJI.get(rarity, "📦")
    rtag   = rarity.capitalize()
    icon   = codex_mod["icon"] if codex_mod else re

    accent = {"rare": 0xD4AF37, "uncommon": 0x4B9CDB, "common": 0x888888}.get(rarity, 0x1F4E5F)

    rk_bar = _rank_bar(rank, max_r)

    cur_stats  = _stat_at_rank(codex_mod, rank) if codex_mod else {}
    next_stats = _stat_at_rank(codex_mod, rank + 1) if (codex_mod and rank < max_r) else {}

    cur_lines  = [_fmt_stat(k, v) for k, v in cur_stats.items()]  if cur_stats  else ["*No stats at this rank (rank 0)*"]
    next_lines = [_fmt_stat(k, v) for k, v in next_stats.items()] if next_stats else ["—"]

    endo_needed   = _endo_cost_at_rank(codex_mod, rank, rarity) if rank < max_r else 0
    credit_needed = _credit_cost_at_rank(codex_mod, rank, rarity) if rank < max_r else 0

    header_text = (
        f"{icon} **{name}** — {re} {rtag}\n"
        f"<:combo:1499663262520971326> **UUID:** `{uuid}`\n"
        f"<:wf_lotus:1499651243101126816> **Owner:** {owner_name} *(ID: {owner_id})*\n"
        f"<:damage:1499651176419950622> **Location:** {warframe_ctx}\n"
        f"<:damage_reduction:1499651603945226260> **Rank:** {rk_bar}"
    )

    stats_text = (
        f"**Current Stats (Rank {rank}):**\n"
        + "\n".join(f"  • {s}" for s in cur_lines)
    )

    if rank < max_r:
        stats_text += (
            f"\n\n**Next Rank ({rank + 1}) Stats:**\n"
            + "\n".join(f"  • {s}" for s in next_lines)
            + f"\n\n<:endo:1499750353002954792> **Upgrade Cost:** `{endo_needed:,}` Endo  ·  💰 `{credit_needed:,}` Credits"
        )
    else:
        stats_text += "\n\n✅ **Max Rank reached!**"

    codex_text = ""
    if codex_mod:
        desc       = codex_mod.get("description", "")
        cat        = codex_mod.get("category", "?")
        pol        = codex_mod.get("polarity", "any").capitalize()
        drain_base = codex_mod.get("base_drain", "?")
        drain_max  = codex_mod.get("max_drain", "?")
        codex_text = (
            f"**Category:** {cat}  ·  **Polarity:** {pol}  ·  "
            f"**Drain:** {drain_base}→{drain_max}\n"
            f"*{desc}*"
        )

    upgrade_hint = ""
    if is_owner and rank < max_r:
        upgrade_hint = f"\nUse `!mods upgrade {uuid}` to rank up."

    cb = (
        _CB(accent_colour=accent)
        .text(header_text)
        .sep()
        .text(stats_text)
    )
    if codex_text:
        cb.sep(visible=False)
        cb.text(codex_text)
    if upgrade_hint:
        cb.sep(visible=False)
        cb.text(upgrade_hint)

    layout = discord.ui.LayoutView()
    layout.add_item(cb.build())
    return layout


# ─────────────────────────────────────────────────────────────────────────────
# !mods upgrade  (confirmation view)
# ─────────────────────────────────────────────────────────────────────────────

class UpgradeConfirmView(discord.ui.View):
    def __init__(
        self,
        owner_id:     int,
        mod_uuid:     str,
        mod_name:     str,
        mod_icon:     str,
        mod_rarity:   str,
        cur_rank:     int,
        max_rank:     int,
        endo_cost:    int,
        credit_cost:  int,
        endo_have:    int,
        credits_have: int,
    ) -> None:
        super().__init__(timeout=30)
        self.owner_id     = owner_id
        self.mod_uuid     = mod_uuid
        self.mod_name     = mod_name
        self.mod_icon     = mod_icon
        self.mod_rarity   = mod_rarity
        self.cur_rank     = cur_rank
        self.max_rank     = max_rank
        self.endo_cost    = endo_cost
        self.credit_cost  = credit_cost
        self.endo_have    = endo_have
        self.credits_have = credits_have

        # Per-user custom_ids prevent button conflicts between concurrent upgrades
        confirm_btn = discord.ui.Button(
            label="Confirm Upgrade",
            style=discord.ButtonStyle.success,
            emoji="⬆️",
            custom_id=f"mods_upgrade_confirm_{owner_id}",
        )
        cancel_btn = discord.ui.Button(
            label="Cancel",
            style=discord.ButtonStyle.secondary,
            emoji="❌",
            custom_id=f"mods_upgrade_cancel_{owner_id}",
        )
        confirm_btn.callback = self._confirm_cb
        cancel_btn.callback  = self._cancel_cb
        self.add_item(confirm_btn)
        self.add_item(cancel_btn)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "This confirmation belongs to another Operator.", ephemeral=True
            )
            return False
        return True

    async def _confirm_cb(self, interaction: discord.Interaction) -> None:
        profile  = await load_player(self.owner_id)
        mod_inst = _get_mod_by_uuid(profile, self.mod_uuid)

        if mod_inst is None:
            await interaction.response.edit_message(
                content="❌ Mod not found in your collection.", view=None
            )
            self.stop()
            return

        cur_rank   = mod_inst.get("rank", 0)
        max_rank   = mod_inst.get("max_rank", self.max_rank)
        mod_rarity = mod_inst.get("rarity", "common")

        if cur_rank >= max_rank:
            await interaction.response.edit_message(
                content=f"✅ **{self.mod_name}** is already at max rank.", view=None
            )
            self.stop()
            return

        endo_have    = profile.get("inventory", {}).get("Endo", 0)
        credits_have = profile.get("credits", 0)
        cm           = _get_codex_mod(self.mod_name)
        endo_cost    = _endo_cost_at_rank(cm, cur_rank, mod_rarity)
        cred_cost    = _credit_cost_at_rank(cm, cur_rank, mod_rarity)

        if endo_have < endo_cost:
            await interaction.response.edit_message(
                content=(
                    f"❌ Not enough Endo.\n"
                    f"Need **{endo_cost:,}**, have **{endo_have:,}**."
                ),
                view=None,
            )
            self.stop()
            return

        if credits_have < cred_cost:
            await interaction.response.edit_message(
                content=(
                    f"❌ Not enough Credits.\n"
                    f"Need **{cred_cost:,}**, have **{credits_have:,}**."
                ),
                view=None,
            )
            self.stop()
            return

        # Deduct Endo
        new_endo = endo_have - endo_cost
        if new_endo == 0:
            profile["inventory"].pop("Endo", None)
        else:
            profile["inventory"]["Endo"] = new_endo
        # Deduct Credits
        profile["credits"] = credits_have - cred_cost
        # Rank up
        mod_inst["rank"] = cur_rank + 1
        await save_player(profile)

        new_rank    = mod_inst["rank"]
        new_stats   = _stat_at_rank(cm, new_rank) if cm else {}
        stat_strs   = [_fmt_stat(k, v) for k, v in new_stats.items()]
        stat_block  = ", ".join(stat_strs) or "—"
        rem_endo    = profile.get("inventory", {}).get("Endo", 0)
        rem_credits = profile.get("credits", 0)

        next_endo    = _endo_cost_at_rank(cm, new_rank, mod_rarity) if new_rank < max_rank else 0
        next_credits = _credit_cost_at_rank(cm, new_rank, mod_rarity) if new_rank < max_rank else 0
        next_msg     = (
            f"\nNext rank: `{next_endo:,}` Endo + `{next_credits:,}` Credits."
            if new_rank < max_rank else "\n✅ **Max rank reached!**"
        )

        await interaction.response.edit_message(
            content=(
                f"{self.mod_icon} **{self.mod_name}** `[{self.mod_uuid}]` upgraded to "
                f"**Rank {new_rank}/{max_rank}**!\n"
                f"Stats: {stat_block}\n"
                f"<:endo:1499750353002954792> Endo remaining: `{rem_endo:,}`  ·  "
                f"💰 Credits remaining: `{rem_credits:,}`"
                f"{next_msg}"
            ),
            view=None,
        )
        self.stop()

    async def _cancel_cb(self, interaction: discord.Interaction) -> None:
        await interaction.response.edit_message(content="Upgrade cancelled.", view=None)
        self.stop()

    async def on_timeout(self) -> None:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Cog
# ─────────────────────────────────────────────────────────────────────────────

class ModsCog(commands.Cog, name="Mods"):

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ── !mods / !mod (base — show collection) ─────────────────────────────────
    # "mod" alias added so both !mods and !mod work.

    @commands.group(
        name="mods",
        aliases=["mod", "modlist", "modcollection"],
        invoke_without_command=True,
    )
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def mods_cmd(self, ctx: commands.Context) -> None:
        """Browse your mod collection, stacked by mod name with individual UUIDs.
        Also available as !modlist."""
        profile  = await load_player(ctx.author.id)
        groups   = _group_mods(profile.get("mod_collection", []))
        endo     = profile.get("inventory", {}).get("Endo", 0)
        credits_ = profile.get("credits", 0)

        layout = _build_mods_list_layout(
            user_id    = ctx.author.id,
            mod_groups = groups,
            page       = 0,
            endo_amount= endo,
            credits    = credits_,
            owner_name = ctx.author.display_name,
        )
        # ⚠️  Components v2 LayoutView must be sent with view= only — no content=
        await ctx.send(view=layout)

    # ── !mods upgrade / !mod upgrade <uuid> ───────────────────────────────────

    @mods_cmd.command(name="upgrade", aliases=["up", "rank"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def mods_upgrade(self, ctx: commands.Context, mod_uuid: str) -> None:
        """
        Upgrade a mod by its UUID using Endo + Credits from your inventory.

        Usage:
          !mods upgrade A9X4M2Q
        """
        mod_uuid = mod_uuid.strip().upper()
        profile  = await load_player(ctx.author.id)
        mod_inst = _get_mod_by_uuid(profile, mod_uuid)

        if mod_inst is None:
            await ctx.send(
                f"<:wf_lotus:1499651243101126816> ❌ Mod `{mod_uuid}` not found in **your** collection.\n"
                "Use `!mods` to browse your mods and find the UUID.",
                delete_after=12,
            )
            return

        name     = mod_inst["name"]
        cur_rank = mod_inst.get("rank", 0)
        max_rank = mod_inst.get("max_rank", 5)
        rarity   = mod_inst.get("rarity", "common")
        cm       = _get_codex_mod(name)
        icon     = cm["icon"] if cm else _RARITY_EMOJI.get(rarity, "📦")

        if cur_rank >= max_rank:
            await ctx.send(
                f"{icon} **{name}** `[{mod_uuid}]` is already at **max rank** ({max_rank}).",
                delete_after=10,
            )
            return

        endo_have    = profile.get("inventory", {}).get("Endo", 0)
        credits_have = profile.get("credits", 0)
        endo_cost    = _endo_cost_at_rank(cm, cur_rank, rarity)
        credit_cost  = _credit_cost_at_rank(cm, cur_rank, rarity)

        cur_stats  = _stat_at_rank(cm, cur_rank) if cm else {}
        next_stats = _stat_at_rank(cm, cur_rank + 1) if cm else {}
        cur_str    = ", ".join(_fmt_stat(k, v) for k, v in cur_stats.items()) or "*No stats at rank 0*"
        next_str   = ", ".join(_fmt_stat(k, v) for k, v in next_stats.items()) or "—"

        rk_bar      = _rank_bar(cur_rank, max_rank)
        can_endo    = endo_have >= endo_cost
        can_credits = credits_have >= credit_cost
        can_rank    = can_endo and can_credits

        re = _RARITY_EMOJI.get(rarity, "📦")
        content = (
            f"{icon} **{name}** `[{mod_uuid}]` — {re} {rarity.capitalize()}\n"
            f"Rank: {rk_bar}\n\n"
            f"**Current stats (Rank {cur_rank}):** {cur_str}\n"
            f"**After upgrade (Rank {cur_rank + 1}):** {next_str}\n\n"
            f"<:endo:1499750353002954792> **Endo needed:** `{endo_cost:,}`  ·  "
            f"**You have:** `{endo_have:,}` {'✅' if can_endo else '❌'}\n"
            f"💰 **Credits needed:** `{credit_cost:,}`  ·  "
            f"**You have:** `{credits_have:,}` {'✅' if can_credits else '❌'}"
        )

        if not can_rank:
            missing_parts = []
            if not can_endo:
                missing_parts.append(f"`{endo_cost - endo_have:,}` more Endo")
            if not can_credits:
                missing_parts.append(f"`{credit_cost - credits_have:,}` more Credits")
            await ctx.send(
                content + f"\n\n❌ **Cannot upgrade.** Need {' and '.join(missing_parts)}.",
                delete_after=15,
            )
            return

        # UpgradeConfirmView is a plain legacy discord.ui.View — content= is fine here
        view = UpgradeConfirmView(
            owner_id     = ctx.author.id,
            mod_uuid     = mod_uuid,
            mod_name     = name,
            mod_icon     = icon,
            mod_rarity   = rarity,
            cur_rank     = cur_rank,
            max_rank     = max_rank,
            endo_cost    = endo_cost,
            credit_cost  = credit_cost,
            endo_have    = endo_have,
            credits_have = credits_have,
        )
        await ctx.send(
            content=content + "\n\n⚠️ Confirm to spend Endo + Credits — **30 seconds to decide.**",
            view=view,
        )

    # ── !mods view / !mod view <uuid> ─────────────────────────────────────────

    @mods_cmd.command(name="view", aliases=["inspect", "info", "v"])
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def mods_view(self, ctx: commands.Context, mod_uuid: str) -> None:
        """
        Inspect any mod by UUID — shows owner, rank, current/next stats,
        upgrade costs, and which Warframe it is equipped on.

        Usage:
          !mods view A9X4M2Q
        """
        mod_uuid = mod_uuid.strip().upper()

        # Fast path — own collection (case-insensitive)
        profile      = await load_player(ctx.author.id)
        mod_inst     = _get_mod_by_uuid(profile, mod_uuid)
        is_owner     = True
        owner_id_str = str(ctx.author.id)
        owner_name   = ctx.author.display_name

        if mod_inst is None:
            # Cross-player search
            is_owner = False
            async with ctx.typing():
                owner_id_str, mod_inst = await find_mod_by_uuid(mod_uuid)

            if mod_inst is None:
                await ctx.send(
                    f"<:wf_lotus:1499651243101126816> ❌ No mod with UUID `{mod_uuid}` found "
                    f"in any Tenno's collection.\n"
                    f"Use `!mods` to see your mod UUIDs.",
                    delete_after=14,
                )
                return

            try:
                owner      = await self.bot.fetch_user(int(owner_id_str))
                owner_name = owner.display_name
                is_owner   = (owner.id == ctx.author.id)
            except Exception:
                owner_name = f"Unknown Operator (`{owner_id_str}`)"

        # Determine equipped warframe context
        eq_on  = mod_inst.get("equipped_on_warframe")
        wf_ctx = "Not equipped"
        if eq_on:
            try:
                target_profile = profile if is_owner else await load_player(int(owner_id_str))
                for wf in target_profile.get("warframe_roster", []):
                    if wf.get("instance_id") == eq_on:
                        wf_name    = wf["warframe_name"]
                        slot_label = ""
                        em         = wf.get("equipped_mods", {})
                        for s_key, s_data in em.items():
                            if s_data and s_data.get("mod_uuid", "").upper() == mod_uuid:
                                slot_label = f" slot {s_key}"
                                break
                        wf_ctx = f"Equipped on **{wf_name}** `[{eq_on}]`{slot_label}"
                        break
                else:
                    wf_ctx = f"Equipped on Warframe `[{eq_on}]`"
            except Exception:
                wf_ctx = f"Equipped on Warframe `[{eq_on}]`"

        cm = _get_codex_mod(mod_inst["name"])
        layout = _build_mod_view_layout(
            mod_inst     = mod_inst,
            codex_mod    = cm,
            owner_name   = owner_name,
            owner_id     = owner_id_str,
            warframe_ctx = wf_ctx,
            is_owner     = is_owner,
        )
        # Components v2 LayoutView — no content=
        await ctx.send(view=layout)

    # ── Error handlers ────────────────────────────────────────────────────────

    @mods_cmd.error
    async def mods_error(self, ctx: commands.Context, error) -> None:
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(
                f"⏳ Try again in `{error.retry_after:.1f}s`, Tenno.",
                delete_after=5,
            )
        else:
            raise error

    @mods_upgrade.error
    async def upgrade_error(self, ctx: commands.Context, error) -> None:
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(
                "<:wf_lotus:1499651243101126816> Provide a mod UUID.\n"
                "Usage: `!mods upgrade A9X4M2Q`\n"
                "Use `!mods` to see your mod UUIDs.",
                delete_after=10,
            )
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏳ Try again in `{error.retry_after:.1f}s`.", delete_after=5)
        else:
            raise error

    @mods_view.error
    async def view_error(self, ctx: commands.Context, error) -> None:
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(
                "<:wf_lotus:1499651243101126816> Provide a mod UUID.\n"
                "Usage: `!mods view A9X4M2Q`",
                delete_after=10,
            )
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏳ Try again in `{error.retry_after:.1f}s`.", delete_after=5)
        else:
            raise error


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ModsCog(bot))
